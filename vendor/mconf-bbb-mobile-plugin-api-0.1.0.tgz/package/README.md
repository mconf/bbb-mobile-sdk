# Mobile plugin API

The contract between the plugin host of the BigBlueButton mobile SDK and its plugins:

- the types of the host (`MobilePluginHost`), of a plugin (`MobilePluginDefinition`) and of
  the items the host draws for a plugin (selector rows, dialogs, notices);
- `definePlugin`, which declares a plugin;
- a mock host for plugin unit tests, under `@mconf/bbb-mobile-plugin-api/testing`.

This folder is its own npm package, with its own dependencies and lockfile. The app installs
its tarball from `vendor/` as a dev dependency, and host apps install the same tarball. It is
not part of the app's build, lint or type-check.

Host code in the app must import the built package, never `src/`: Metro does not resolve
the `.js` import paths in `src/` to their `.ts` files. Under Metro, the root entry resolves
whether package exports are on or off. The app's `metro.config.js` turns them off, and then
`./testing` does not resolve; it is meant for a test runner.

## Status and versioning

The version is `0.x`. **There is no compatibility promise before 1.0: any 0.x release may
break plugins.**

Each plugin declares the host API versions it works with in `requiredHostApi`, as a semver
range in npm's full grammar: comparators (`>=0.1.0 <0.3.0`), hyphen ranges, x-ranges, caret,
tilde, exact versions and `||`. The host compares the range with its own version when it
loads the plugin, and skips and logs a plugin that does not match. npm's pre-release rule
applies: a pre-release host version satisfies only a range that names a pre-release of the
same `major.minor.patch`. The check itself is host code and is not in this package.

The version is in two places that must agree: `version` in `package.json` and
`HOST_API_VERSION` in `src/version.ts`. It may be a pre-release, such as `0.2.0-beta.1`.

## Using it from a plugin

The package is not published to npm. Build a tarball from a commit of this repository and
install the file:

```bash
cd plugin-api
npm ci
npm pack        # builds dist/ and writes mconf-bbb-mobile-plugin-api-<version>.tgz
```

```bash
# in the plugin
npm install --save-dev /path/to/mconf-bbb-mobile-plugin-api-<version>.tgz
```

A plugin that bundles this package into its build can keep it as a dev dependency. A plugin
that ships unbundled source, for the app's bundler to build, lists it as a peer dependency
and as a dev dependency for its own tests. The app installs the same tarball itself: the app
does not install a plugin's dev dependencies, and npm cannot fetch the peer, since the package
is not on npm.

Write the peer dependency by hand as a semver range, such as `^0.1.0` (the same range as
`requiredHostApi`), not the `file:` spec that the install command writes.

Record the commit the tarball was built from. During development, build the tarball from a
local checkout the same way. Do not depend on the folder itself (`file:` to the folder): npm
links it, and the folder's own `node_modules` brings a second copy of React, so hooks fail
with "Invalid hook call".

```ts
import { definePlugin } from '@mconf/bbb-mobile-plugin-api';

export default definePlugin({
  name: 'example-plugin',
  requiredHostApi: '^0.1.0',
  create(host) {
    const Headless = () => {
      const locale = host.useLocale();
      // ...
      return null;
    };
    return { Headless };
  },
});
```

```ts
import { createMockHost } from '@mconf/bbb-mobile-plugin-api/testing';

const { host, controller } = createMockHost();
```

`react` is a peer dependency, in the range `^18.2.0 || ^19.0.0`. The package is ES modules
only: a test runner that loads it as CommonJS (such as Jest without a transform for this
package) cannot import it. Its types import React's, so a TypeScript plugin also needs
`@types/react`. Both entries resolve under the `moduleResolution` settings `node` and
`bundler`, and under `node16` and `nodenext` from an ES module.

## Working on the contract

Use the Node version in the repository's `.nvmrc`.

| Command | What it does |
|---|---|
| `npm ci` | Installs this folder's dependencies. |
| `npm test` | Runs the unit tests and the conformance cases against the mock host. |
| `npm run test:react18` | Installs React 18.2 in `test/react18`, then runs the same tests on it. |
| `npm run typecheck` | Type-checks `src/` and `test/`, and `test/sdk-host` with the app's host code. |
| `npm run build` | Writes `dist/`. |
| `npm run api:check` | Builds, then checks the API reports and the version rule. |
| `npm run api:update` | Builds, then rewrites the API reports in `etc/`. |
| `npm run vendor:check` | Packs this folder and checks that `../vendor/` and the root lockfile hold that tarball. |
| `npm run vendor:update` | Packs this folder into `../vendor/`, replacing the older tarball. |

A change here that reaches the tarball (`src/`, `package.json`, this README) needs a new
tarball: run `npm run vendor:update`, then, at the repository root,
`npm install --save-dev --save-exact ./vendor/mconf-bbb-mobile-plugin-api-<version>.tgz`.
Install it by its path: a plain `npm install` keeps the old integrity hash in the lockfile. CI runs
`vendor:check`.

### API reports

`etc/plugin-api.api.md` and `etc/plugin-api-testing.api.md` list everything the package
exports. They are generated by API Extractor and committed.

`npm run api:check` fails when:

1. `HOST_API_VERSION` differs from the version in `package.json`, or the version is not a
   semver version;
2. a report differs from what the build produces (run `npm run api:update`), or API
   Extractor reports an error or a warning;
3. the version is lower, in semver order, than at the merge-base with the base branch;
4. a report differs from the merge-base, and the version does not have a higher
   `major.minor` than both the version at the merge-base and the version at the tip of the
   base branch, apart from the pre-release case below.

Pre-releases of one version may change the API among themselves and in the release. So in
rule 4, a version also passes against a pre-release when it is higher in semver order and
has the same `major.minor.patch`: `0.2.0-beta.2` and `0.2.0` both pass after
`0.2.0-beta.1`, but `0.2.1`, a higher patch, does not.

So a change to a report needs a higher minor (or major) version. So does a change to
documented behaviour, or to a conformance case or todo, although it leaves the reports alone:
they hold signatures, not TSDoc text, and the check cannot see it. Say so in the pull request
description, and raise the version. A change that leaves the reports, the documented
behaviour and the conformance cases alone needs at most a higher patch version.

The base branch is `origin/mobile-plugins/trunk`; set `API_BASE_REF` to compare with another
ref.

Rule 4 reads the tip too: when two pull requests from one commit raise the version to the
same value, the second fails once the first has merged. CI runs the check on pull requests,
after a push to the base branch and in a merge queue. A merge queue fails the second before
it merges. Without one, the run after the second push fails.

`npm run api:update` rewrites both reports even when API Extractor warns. It fails on an API
Extractor error, or on a version that breaks rule 1.

A pull request that changes the contract includes the report diff. Right before it merges,
fetch the base branch, run `npm run api:check` again and paste its output: the check reads
the tip of the base branch only as far as the last fetch.

### The app's host

The app's plugin host is in the repository's `src/plugins/`. It imports only this package,
`semver` and React types, so `test/sdk-host/` can test it here; the app has no test runner.
In CI only this folder is installed, so `vitest.config.ts` resolves the package name to
`src/index.ts` and `semver` to this folder's copy. `tsconfig.sdk-host.json` type-checks those
tests and the host code with bundler resolution, since the app's files are not ES modules
under `nodenext`.

### Conformance cases

`test/conformance/suite.ts` holds the cases every host must pass. Today they run against the
mock host. A case that needs host code that does not exist yet is an `it.todo`; it becomes a
test in the pull request that adds that code.

The suite runs against the mock host too, so that pull request also changes the mock: either
the mock follows the new rule, or the case skips the mock and the rule is added to the list in
the TSDoc of `createMockHost`.
